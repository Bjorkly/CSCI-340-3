// TA: -0.6 Bad formatting in output
// TA: Total -> 9.4

/*     Berkley Phelps
    Z1906725
    CSCI 340 Section 3

    I certify that this is my own work and where appropriate an extension 
    of the starter code provided for the assignment.
*/

//#include "car.h"
#include "garage.h"
#include<string>
#include<iostream>
#include<fstream>
#include<algorithm>
#include<vector>

using std::string;
using std::ifstream;
using std::endl;

//gets each line, the arrival type and license number and prints them out
void get_input_vals(const std::string &line, char &xact_type, std::string &license)
{
    ssize_t startLine = 0;
    ssize_t found = 0;

    //takes out the first :
    found = line.find(':', startLine);
    xact_type = line.at(0);

    startLine = found + 1;
    //takes out the second :
    found = line.find(':', startLine);
    license = line.substr(startLine, found - 2);
}

int main()
{
    //opens up the input file
    //reads each line in a while loop
    string read;
    char type;
    string licenseNum;
    garage g;
    while(getline(std::cin, read))
    {
        //read line then starts reading the next line till done
        get_input_vals(read, type, licenseNum);

        //checks if the car is arrived or departed
        if(type== 'A')
        {
            g.arrival(licenseNum);
        }
        else if(type=='D')
        {
            g.departure(licenseNum);
        }
        else
        {
            std::cout<<"'"<< type<<"': invalid action!"<<endl;
        }
    }
}
