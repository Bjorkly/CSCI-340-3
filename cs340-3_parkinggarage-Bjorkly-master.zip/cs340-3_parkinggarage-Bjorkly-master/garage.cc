#include "garage.h"

void garage::arrival(const std::string &license)
{   //checks to see if garage is full. If not than enter the car
    car enterCar(next_car_id, license);
    if(parking_lot.size()<10)
    {
    
    parking_lot.push_back(enterCar);
    std::cout<<enterCar<<"has arrived."<<std::endl;
    next_car_id++;
    }
        else
    {
        std::cout<<enterCar<<"\n    But the garage is full!"<<std::endl;
    }
}

void garage::departure(const std::string &license)
{   //checks to see if the car found. If not the car is put in a tempory parking lot to hold on for.
    bool isFound = false;
    int position = 0;
    std::stack<car> temp_parking_lot;
 //checks the parking lot to get licenses
 for( auto i : parking_lot)
{
    if(license==i.get_license())
    {
        isFound=true;
        break;
    } 
    position++;
}
if(!isFound)
  {
      std::cout<<"No car with license plate\""<<license<<"\" is in the garage."<<std::endl;
      return;
  }

//moves the car
for(int i = 0; i < position; i++)
{
    //puts the temp car to the front of the parking lot
    auto tempCar=parking_lot.front();

    tempCar.move();
    //pushes the temp car from the lot
    temp_parking_lot.push(tempCar);
    //pops the front car in the lot
    parking_lot.pop_front();
}
    auto tempCarMove=parking_lot.front();
    tempCarMove.move();
  std::cout<<tempCarMove<<"has departed."<<std::endl;
  std::cout<<"car was moved "<< tempCarMove.get_num_moves()<<" time in the garage."<<std::endl<<std::endl;

//pops the car off
 parking_lot.pop_front();

//pushes back the car
for(int i = 0; i < position; i++)
{
    parking_lot.push_front(temp_parking_lot.top());

    temp_parking_lot.pop();
}

}
