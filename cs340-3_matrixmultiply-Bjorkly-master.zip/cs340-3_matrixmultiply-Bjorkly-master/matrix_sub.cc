/*
    Berkley Phelps
    Z1906725
    CSCI 340 Section 3
    I certify that this is my own work and where appropriate an extension 
    of the starter code provided for the assignment.
*/


/**
 * @file matrix_sub.cc
 */
#include "matrix.h"

/**
 * @brief Opens two data files for reading and creates the input streams `is1` and `is2`.
 *
 * Opens two data files for reading and creates the input streams `is1` and `is2`.
 * If either file fails to open, it prints an error message on stderr and aborts the program with
 * a non-zero exit value. The names of the input files are `matrix01.dat` and `matrix02.dat`, 
 * whose full path names are defined as `FILE1` and `FILE2` in the header file `matrix.h` all 
 * included within starter repository.
 * 
 * @param is1 the first input stream
 * @param is2 the second input stream
 */
void open_files(ifstream &is1, ifstream &is2)
{
    // open FILE1 as is1
    is1.open (FILE1, std::ifstream::in);
    // open FILE2 as is2
    is2.open (FILE2, std::ifstream::in);
}

/**
 * @brief Reads the input values from the input stream is and stores them in matrix `m`
 *
 * Reads the input values from the input stream is and stores them in matrix `m`, 
 * which is defined as a two-dimensional vector of integers. 
 * The number of rows and columns of `m` are the pair of values given at the beginning 
 * of the corresponding data file and they are captured in the source file `matrix.cc` 
 * (driver program) that is in the same directory with `matrix.h`.
 * 
 * @param is contains data that we read from
 * @param m matrix to be filled
 */
void read_data(ifstream &is, vector <vector <int> > &m)
{
    int numberOfCols = m.size();
    int numberOfRows = m[0].size();
    // iterating over every vector <int> inside m
    for(int i=0; i<numberOfCols; i++)
    {
        //iterating over every item in the interal vector
        for(int j=0; j<numberOfRows; j++)
        {
             // use this >> to read values from is into every item in the m
            is>>m[i][j];
        }
    }

           
}

/**
 * @brief Prints the contents of the matrix
 *
 * Prints the contents of the matrix &m on stdout by allocating `ITEM_W` spaces for each integer value, 
 * which is defined in the header file `matrix.h`. The number of values printed in a single line
 * equals to the number of columns of `m` and the number of lines on stdout equals to the number
 * of rows of `m`.
 * 
 * @param m matrix to be printed
 */
void print_data(const vector <vector<int>> &m)
{
    // iterating over every vector <int> inside m
    for (auto &row : m)
    {
        // iterating over every item in the interal vector
        for (auto &item : row)
        {
            // use this << to print values from is into every item in the m 
            cout << setw(ITEM_W) << item;
        }
           
        // at the end of the row print out endl
        cout << endl;
    }   
}

/**
 * @brief It multiples the values in the matrices `A` and `B` and stores the results in the matrix `C`
 * 
 *
 * It multiples the values in the matrices `A` and `B` and stores the results in the matrix `C`. 
 * - If `C(i, j)` is the value of `C` in row `i` and column `j` of `C`, then `C(i, j) += A(i, k) * B(k, j)` for all index values of `k`, where `A(i, k)` is the value of `A` in row `i` and column `k` of `A`, and `B(k, j)` is the value of `B` in row `k` and column `j` of `B`. 
 * - For a vector container use `C[i][j]` for `C(i, j)`, where `i = 0, 1, ..., size(C) - 1` and `j = 0, 1, ..., C[i].size() - 1`, and it's the same for `A` and `B`.
 * - See also: (https://en.wikipedia.org/wiki/Matrix_multiplication)
 *
 * @param A multpicand matrix
 * @param B multpiler matrix
 * @param C dot product matrix
 */
void gen_data(const vector<vector<int>> &A, 
              const vector<vector<int>> &B, 
              vector<vector<int>> &C)
{

    for(auto&C = i)
    {
        for(auto&A = j)
        {
            for(auto&B = k){}
        }
    }
    C[i][j] += A[i][k]*B[k][j];
}