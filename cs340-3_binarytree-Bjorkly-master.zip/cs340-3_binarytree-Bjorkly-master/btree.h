/*TA Comments:
Good Job!: 9.5/10
-no proper doc-box for functions
*/


/*     Berkley Phelps
    Z1906725
    CSCI 340 Section 3
    I certify that this is my own work and where appropriate an extension 
    of the starter code provided for the assignment.
*/

#ifndef H_BTREE
#define H_BTREE

#include "node.h"
#include <cstddef>
#include <stdlib.h>
#include <iostream>

using namespace std;

 typedef enum {left_side, right_side } SIDE;
 SIDE rnd()
 { 
     return rand()%2 ? right_side : left_side;
 }// End of rnd()

template <typename T> class BinaryTree{

public:
    BinaryTree();                                      // default constructor
    unsigned     getSize() const;                    // returns size of tree
    unsigned     getHeight() const;                    // returns height of tree
    virtual void Insert(const T&);                     // inserts node in tree
    void         Inorder(void (*)(const T&));          // inorder traversal of tree

protected:
    Node<T> *root;                                      // root of tree

private:
    unsigned _getSize(Node<T> *) const;                 // private version of getSize()
    unsigned _getHeight(Node<T> *) const;               // private version of getHeight()
    void     _Insert(Node<T> *&, const T&);             // private version of Insert()
    void     _Inorder(Node<T> *, void (*)(const T&));   // private version of Inorder()
};


template <typename T>
BinaryTree<T>::BinaryTree()
{
    root = nullptr;
}

//get size of tree
template <typename T>
unsigned BinaryTree<T>::getSize() const
{
    return _getSize(root);
}

//gets height of tree
template <typename T>
unsigned BinaryTree<T>::getHeight() const
{
    return _getHeight(root);
}


//inserts node into tree
template <typename T>
void BinaryTree<T>::Insert(const T&x)
{
    _Insert(root, x);
}

//reads the tree inorder
template <typename T>
void BinaryTree<T>::Inorder(void (*rem)(const T&))
{
    _Inorder(root, rem);
}


//returns the size of the tree
template <typename T>
unsigned BinaryTree<T>::_getSize(Node<T> *size) const
{
    if(size==0)
    {
        return 0;
    }
    //checks the size of the left and right child and add them together. The 1 is the parent node 
    else
    {
        return _getSize(size -> left) + _getSize(size -> right) + 1;
    }
}

//returns height of the tree
template <typename T>
unsigned BinaryTree<T>::_getHeight(Node<T> *height) const
{
    if(height == 0)
    {
        return 0;
    }
    else
    {
        
        int RH = _getHeight(height -> right);
        int LH = _getHeight(height -> left);
        
        //Checks to see if left is great than right or vice versa
        if(LH > RH)
            return LH+1;
        else
            return RH+1; 
    }
}

// inserts node in tree
template <typename T>
void BinaryTree<T>::_Insert(Node<T> *&root, const T&x)
{   
    //Checks to see if root is empty. If empty then add a new node
    if( root == 0)
    {
        Node <T> * NewNode;
        NewNode = new Node <T>(x);
        root = NewNode;
    }
    else
    {
        //Calls rnd to see if its left or right side then inserts nood into said side
        if(rnd()== SIDE::left_side)
        {
            _Insert(root -> left, x);
        }
        else
        {
            _Insert(root -> right, x);
        }
       
    }
}

//inorder traversal of tree
template <typename T>
void BinaryTree<T>::_Inorder(Node<T> *root, void (*print)(const T&x))
{
    if( root == 0)
    {
        return;
    }
    //If the root is not null then checks the children
    else
    {   //Moves from the node to left child
        _Inorder(root -> left, print);
        //Moves back up to node and prints itself
        print(root -> data);
        //Moves from the node to right child
        _Inorder(root -> right, print);
    }
}

#endif // End of H_BTREE
