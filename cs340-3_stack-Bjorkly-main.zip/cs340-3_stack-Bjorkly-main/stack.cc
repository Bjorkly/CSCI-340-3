/* 	Berkley Phelps
	Z1906725
	CS340.1
	
	I certify that this is my own work and where appropriate an extension 
	of the starter code provided for the assignment.
*/
#include "stack.h"

//Make sure both 'q1' and 'q2' are empty
bool Stack::empty() const
{   
    //checks if either queue are empty
    bool que;
    if(q1.empty()&&q2.empty())
    {
        que=true;
    }
    else
    {
        que=false;
    }
    return que;
}

//Counts the number of elements in both `q1` and `q2`
int Stack::size() const
{
    return q1.size()+q2.size();
}

//Returns the newest element
int Stack::top()
{
    int hold;
    if(!q1.empty())
    {
        hold=q1.front();
    }
    else
    {
        hold=q2.front();
    }
    return hold;
}

//Adds element to non-emtpy queue
void Stack::push(const int &val)
{
   //Checks if q1 is empty to add values 
    if(q1.empty())
    {
        q1.push(val);
        //Pushes q1 into q2 if q2 isn't empty
        while(!q2.empty())
        {
            q1.push(q2.front());
            q2.pop();
        }
    } //Checks if q2 is empty to add values
    else if(q2.empty())
    {
        q2.push(val);
        //Pushes q2 into q1 if q1 isn't empty
        while(!q1.empty())
        {
            q2.push(q1.front());
            q1.pop();
        }
    }
}

//Removes newest element
void Stack::pop()
{
    if(!q1.empty())
    {
        q1.pop();
    }
    else
    {
        q2.pop();
    }

}
