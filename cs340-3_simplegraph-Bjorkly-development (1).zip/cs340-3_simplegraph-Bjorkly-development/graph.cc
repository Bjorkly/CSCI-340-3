/* 	Berkley Phelps
	Z1906725
	CS340.3
	
	I certify that this is my own work and where appropriate an extension 
	of the starter code provided for the assignment.
*/
#include <iostream>
#include "graph.h"
#include <fstream>
#include <string>
#include <sstream>

// Used to reccord the path of the graph moving from one node to another
std::vector<char> reccorded_path;
// Used as a container for the nodes in the graph
std::vector<std::string> contain;

// Used to check a node was a already visted or not
std::vector<bool> isVisit(7);


void Graph::Depthfirst(int v) 
{   // Checks to see if the node v was vistied or not
    // Searches through the list for a node that was not visitied 
    
    isVisit[v] = true;
    // Adds visted nodes to a reccorded path
    reccorded_path.push_back(labels[v]);
    
    for (auto i = adj_list[v].begin(); i != adj_list[v].end(); ++i)
    {
        // If a node has not been visited then search through the list again  
        if (!isVisit[*i])
        {   
            // Uses string s to hold the first part of the lable
            std::string s(1,labels[v]);
            // Uses string f to hold the second part of the lable
            std::string f(1,labels[*i]);
            // Uses a third string add both previous strings 
            std::string l = "(" + s + ", " + f + ")";
            // Adds the completed lable into a container of visited nodes
            contain.push_back(l); 
            // Starts the proccess all over again till all nodes are vistied
            Depthfirst(*i);
        }
    }   return;
}
/**
 * @brief Construct a new Graph:: Graph object
 * 
 * @param filename name of the input file
 */
Graph::Graph(const char* filename)
{
    std::fstream myfile;
    // Opens the inputfile
    myfile.open(filename);

    // Reads the inputfile
    std::string n;

    myfile >> n;
    // Converts any element for size into anything that is needed
    size = std::stoi(n);

    // Resizes each vector to fit any size
    labels.resize(size);
    adj_list.resize(size);
    
    // reads the labels and puts them into a vector
    for(int i=0; i<size; i++)
    {
        myfile >> n;
        labels[i] = (n[0]);
    }

    // reads the elements into a list? I forgot
    for(int j=0; j<size; j++)
    {
        myfile >> n;
        // reads the elements into a list
        for(int k=0; k<size; k++)
        {
            myfile >> n;
            if (n=="1")
            {
                adj_list[j].push_back(k);
            }
        }
    }   myfile.close();
}

Graph::~Graph()
{
    // No idea what's suppose to be used for but doesn't seem that important
}

int Graph::Getsize() const 
{   // Prints out the size of the graph
    return size;
}

void Graph::Traverse() 
{
    Depthfirst(0);
    // Prints out the path of the graph in preorder
    for( auto i = reccorded_path.begin(); i != reccorded_path.end(); ++i)
        {
            std::cout<< *i<< " ";
        }
        std::cout<<std::endl;
    // Prints out the containers of visited nodes
    for(auto j = contain.begin(); j != contain.end(); ++j)
    {
        std::cout<< *j << " ";
    }
    std::cout<<"\n--------- end of traverse -------"<<std::endl;
}

void Graph::Print() const 
{   // This is here just to match the refout.
    std::cout<<std::endl;
    std::cout<< "Number of vertices in the graph: "<<size<<std::endl<<std::endl;

    std::cout<< "-------- graph -------"<<std::endl;
    
    // Iterate through adj vector then iterate the lists within the vector and print the contents out
    for(int i=0; i<size; i++) 
    {
        std::cout<<labels[i] << ": ";
        // Iterates through the list and prints the contents out
        for( auto j = adj_list[i].begin(); j != adj_list[i].end(); ++j)
        {
            std::cout<<labels[*j];
            ++j;    // This is so that commas will be addeed after each letter
            if(j != adj_list[i].end()) 
            {
                 std::cout << ", ";
            }
            --j;    // This is so there's no comma at the end of the list
        }
            std::cout<<std::endl;
    }
    std::cout<<"------- end of graph ------"<<std::endl<<std::endl;
    std::cout<<"------- traverse of graph ------"<<std::endl;
}