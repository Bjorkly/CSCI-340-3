/*TA Comments:
Good JOb!: 10/10
-please put proper doc-box (points will be cut next time)
/*    
	 Berkley Phelps
    Z1906725
    CSCI 340 Section 3
    I certify that this is my own work and where appropriate an extension 
    of the starter code provided for the assignment.
*/

#ifndef BINARYSEARCHTREE_H_
#define BINARYSEARCHTREE_H_

#include "node.h"
#include "bst.h"
#include "btree.h"
#include <cstddef>
#include <stdlib.h>
#include <iostream>

using namespace std;

template <typename T>
class BinarySearchTree : public BinaryTree<T>
{
public:
    void Insert(const T &x);       // inserts node with value x
    bool Search(const T &x) const; // searches leaf with value x
    bool Remove(const T &x);       // removes leaf with value x
private:
    void _Insert(Node<T> *&, const T &);      // private version of insert
    bool _Search(Node<T> *, const T &) const; // private version of search
    void _Remove(Node<T> *&, const T &);      // private version of remove
    bool _Leaf(Node<T> *node) const;          // checks if node is leaf
};


//inserts node into tree
template <typename T>
void BinarySearchTree<T>::Insert(const T&x)
{
    _Insert(this->root, x);
}

//search for node in tree
template <typename T>
bool BinarySearchTree<T>::Search(const T &x) const
{
    return _Search(this->root, x);
}

//removes leaf from tree
template <typename T>
bool BinarySearchTree<T>::Remove(const T &x)
{
    bool v = Search(x);
    if (v==true)
    {
        _Remove(this->root, x);
    }
   return v;
}


// inserts node in tree
template <typename T>
void BinarySearchTree<T>::_Insert(Node<T> *&r, const T&x)
{   
    //Checks to see if root is empty. If empty then add a new node
    if( r == NULL)
    {
       r = new Node <T>(x);
    }
    else
    {
        // checks if root is greater than or less than data
        if(r->data > x)
        {
            //inserts root to left side
            _Insert(r->left, x);
        }
        else if(r->data < x)
        {
            //inserts root to right side
            _Insert(r->right, x);
        }
       else
        return;
    }
}

//searchs for a leaf with value x
template <typename T>
bool BinarySearchTree<T>::_Search(Node<T> *b, const T &x) const
{
    
    //checks if x matchs the pointer and if x is a leaf node
    if(b==NULL)
    {
        return false;
    }
    
    //checks if node matches x and is a leaf
    else if(x==b->data && _Leaf(b))
    {
        return true;
    }

    //checks if child is less than parent
    else if( x<b->data)
    {
        return _Search(b->left,x);
    }
    //checks if child is greater than parent
    else if(x>b->data)
    {
        return _Search(b->right,x);
    }

    //chekcs if node is null
    else
    {
        return false;
    }
}
//Removes a node from the tree
template <typename T>
void BinarySearchTree<T>::_Remove(Node<T> *& node, const T &x)
{
    //checks if leaf node and the data of leaf is x. If so then node is null
    if(_Leaf(node) && node->data==x)
    {
        node=NULL;
    }
    //checks if x is less than data node and removes removes left node
    else if(x<node->data)
    {
        _Remove(node->left,x);
    }
    ////checks if x is greater than data node and removes removes right node
    else if(x>node->data)
    {
        _Remove(node->right,x);
    }
}

//Checks if a node is a leaf or not 
template <typename T>
bool BinarySearchTree<T>::_Leaf(Node<T> *node) const
{
    //checks if the child of a node are null 
    if(node->left ==NULL && node->right==NULL)
    {
        return true;
    }
    return false;
}
#endif
