#include <iostream>
#include <list>
#include <string>
#include <iomanip>

using namespace std;

int main()
{
    // Initialize firstname with following list "Obi", "Luke", "Master", "Tom", "Hank"
    // Adds all the first names to the list
    list <string> firstname;
    firstname.push_back("Obi");
    firstname.push_back("Luke");
    firstname.push_back("Master");
    firstname.push_back("Tom");
    firstname.push_back("Hank");
    // Initialize lastname with following list "Wan", "Skywalker", "Yoda", "Hanks", "Aaron"
    // Add all the lastnames to the list
    list <string> lastname;
    lastname.push_back("Wan");
    lastname.push_back("Skywalker");
    lastname.push_back("Yoda");
    lastname.push_back("Hanks");
    lastname.push_back("Aaron");

    list <string> fullname;
    // These iterators are so the two lists can be added together in a loop
    std::list<std::string>::iterator it = firstname.begin();
    std::list<std::string>::iterator it2 = lastname.begin();

    // Adds the firstname and the lastname together into a fullname
    // thru a loop depening on the size of the name.
    for(size_t i = 0; i < firstname.size(); i++)
    {
        string st1(*it);
        string st2(*it2);
        fullname.push_back(st1 + " " + st2);

        // the compler required this
        advance(it, 1);
        advance(it2, 1);

    }
    // Prints out the fullname
    for(string i : fullname)
    {
        cout << i << endl;
    }

}