#include "03htable.h"
#include <ostream>

// Hash function, you may NOT modify this function
int HTable::hash(const int k)
{
  return k % hsize;
}

// Second hash function for collision resolution, you may NOT modify this function
int HTable::hash2(const int k)
{
  return 7 - (k % 7);
}

// You will complete the code below ...

int HTable::resolve(const int k, const int i)
{
  int resolvedIndex = -1;

  // Write you code to employ double hashing strategy (use hash2 as second hash function) and 
  // assign the result to resolvedIndex.

  return resolvedIndex % hsize;
}

// The hash table, which is a vector of list<Entry> containers, can be created
// dynamically for a given fixed size hs by its constructor.
HTable::HTable(const unsigned &hs)
{
  hTable.resize(hs);
  hsize = hs;
  hTable.resize(hs);
}

// Since the hash table is implemented as a vector, the destructor
// of the hash table frees the memory for the vector.
HTable::~HTable() {}

// This public function inserts the record of the item e:(key,name) in the hash table.
// If the key already exists in the table, then the function prints an error message;
// otherwise, it prints the index value of the inserted record in the hash table.
// In the case of a collision, call resolve() by passing the key and the index where collision
// occurred as arguments and insert the new record at the index returned by the resolve() method.
void HTable::insert(const Entry &e)
{
  vector <Entry> :: iterator myIt;
  int index = hash(e.key);
  // Creats a copy of the list
  vector <Entry> listCopy = hTable.at(index);
  
  // Scans through the list until a key is found
  for(myIt = listCopy.begin(); myIt!= listCopy.end(); ++myIt)
  {
    // Checks to see if the key exist
    if( myIt->key == e.key)
    {
      std::cout<<"not inserted - duplicate key!!!"<<std::endl;
      return;
    }
  }
}

// This public function prints the subscript and the contents of all (and only) the active
// records in the hash table.
// The following widths should be used for formatting the output:
// index of the table - 2, key - 5, name - 20
void HTable::hTable_print()
{
    //print subscript and contents of all of active rec in table
  for(auto SubScript = hTable.begin(); SubScript != hTable.end(); ++sub)
  {
    std::cout<< setw(2) << hash(name.key) << "-"<< setw(5)<< name.key << " - " << setw(20) << name.key << " - " << name.desc<<std::endl;
  }
}