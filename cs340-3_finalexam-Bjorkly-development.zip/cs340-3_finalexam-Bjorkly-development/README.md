# CS340.1 Final Exam

You will complete this exam in 110 minutes, both parts will be done in class. You may not use any website other than *Microsoft Forms*, *GitHub*, and *www.cplusplus.com*.

## Part One (110 Points) Microsoft Forms

You can find the Microsoft Forms portion of the exam at URL: [https://forms.office.com/r/pgGRM36fZU](https://forms.office.com/r/pgGRM36fZU)

## Part Two (40 Points) C++ Programming
Please complete three of the following four programming questions (you may do the fourth one for extra credit). Follow the class's workflow, having accepted the GitHub Classroom invitation, now browse to newly created GitHub repository, create a **_development_** branch, clone repository to the local machine, or turing/hopper/whick, complete exam, `git commit` and `git push` your results. Issue a single pull request that the exam is now ready for grading.

**Do not edit the Makefile** in the repository. It provides all functionality needed for the exam. The files inside the brackets for each question are the only files you need to modify for that given problem.

1. (10 points) [01list.cc] Write the appropriate code to create an STL list of strings named `firstname` and populate the list with the following words _Bob_, _Joe_, _Sue_, _Tom_, and _Hank_. Now create a second STL list of string named `lastname` and populate it with the following words _Newhart_, _Jonas_, _Dey_, _Jones_, and _Aaron_. Finally, create a third list of strings named `fullname` that is the concatenation of firstname and lastname with a space between them. Print the fullname list with a single name per line using specified formatting.

2. (10 points) [02btree.h] Add two new traversal techniques to binary trees using the included class `02btree.h`, you will be adding the following four functions. You will be modifying only the *BinaryTree* class. DO NOT modify `02binarytree.cc` file, it provides the driver program for evaluating your modification.

    ```c++
    void Preorder(void (*)(const T &));

    void Postorder(void (*)(const T &));
    void _Postorder(Node<T> *, void (*)(const T &));
    ```

3. (10 points) [03hashmain.cc, 03htable.cc] Write a program to demonstrate the double hashing resolution strategy in a hash table. Using the given template code, implement the appropriate methods to read the input file, create a hash table, insert keys using given hash function, and resolve the collisions (if any) using double hashing. You must complete the required code in `03hashmain.cc` and `03htable.cc`. The reference input can be found in `03hash.in` and the corresponding reference output can be found in **03hash.refout**.

4. (10 points) [04graphmain.cc, 04graph.cc] Given a directed graph as set of nodes and edges, write a program to read the graph and create an adjacency matrix representation of it and display the matrix following the formatting rules provided in the code. Also, check if given sequence of nodes form a valid path or not. You must complete the code needed in `04graph.cc`. The reference input can be found in `04graph.in` and the corresponding reference output can be found in **04graph.refout**.


`git commit` and `git push` your local repository to GitHub for grading by the turn-in deadline **(end of 110 minutes)**. Failure to do so on time will result in a **zero** for this portion of the exam.
