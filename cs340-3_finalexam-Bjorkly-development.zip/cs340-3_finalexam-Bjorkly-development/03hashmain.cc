#include "03entry.h"
#include "03htable.h"
#include <fstream>
#include <iostream>

using std::cerr;

int current_size;
int main(int argc, char **argv)
{
    if (argc < 2)
    {
        cerr << "args: input-file-name\n";
        return 1;
    }

    // Read the input file at argv[1]
    if(argv==1)
    {
        cin>>c
    }
    // Create a HTable object using the size (First line of the input file indicates size).
    
    HTable (const unsigned & = TBL_SZ)
    {
        HTable = new int[TBL_SZ];
        current_size = 0;
        for (int i = 0; i < TBL_SZ; i++)
            HTable[i] = -1;
    }
    // Each row (except first one) represents a record - first value is key and second value is name.
        int hash(int key)
    {
        return (key % TBL_SZ);
    }
    // Create Entry objects for each record and insert it into the hash table.
     void insert(const Entry &v)
     {
        // checks if table is full
        if(isFull())
        return;
        // gets index from the first hash
        int index = hash(key);
        
        // if collesion occurs
        if (hashTable[index] != -1)
        {
            // get index2 from second hash
            int index2 = hash2(key);
            int i = 1;
            while (1)
            {
                // get newIndex
                int newIndex = (index + i * index2) % TBL_SZ;
  
                // if no collision occurs, store
                // the key
                if (hashTable[newIndex] == -1)
                {
                    hashTable[newIndex] = key;
                    break;
                }
            } i++;
        }
        
        // no collision at all
        else
            hashTable[index] =key;
        current_size++;
        
    // print the contents of the hash table by calling the appropriate method from the HTable class
      c.Print();

    return 0;
}