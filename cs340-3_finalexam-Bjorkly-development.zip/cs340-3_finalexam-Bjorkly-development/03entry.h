#ifndef H_ENTRY
#define H_ENTRY

#include <string>
using std::string;

#define TBL_SZ 17 // default size for hash table

// entry in hash table
struct Entry
{
  int key;     // key
  string name; // name

  // constructor
  Entry(const int &k = -1, const string &n = "") : key(k), name(n) {}
};

#endif