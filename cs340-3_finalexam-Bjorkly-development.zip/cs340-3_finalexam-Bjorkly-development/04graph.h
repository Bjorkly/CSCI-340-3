#ifndef GRAPH_H
#define GRAPH_H
#include <vector>

using std::vector;

class Graph
{
private:
  int size;
  vector<vector<int> > adj_matrix;
  vector<char> labels;
  vector<char> sequence;
  bool isValidSequence() const;

public:
  Graph(const char *filename);
  ~Graph();
  void Print() const;
};

#endif // GRAPH_H