#include "03entry.h"

#ifndef H_HASH_TABLE
#define H_HASH_TABLE

#include <vector>
using std::vector;

// class for hash table
class HTable
{
public:
  HTable(const unsigned & = TBL_SZ); // constructor
  ~HTable();                         // destructor

  void insert(const Entry &); // inserts item in hash table
  void hTable_print();        // prints hash table entries

private:
  unsigned hsize;       // size of hash table
  vector<Entry> hTable; // hash table

  int hash(const int);    // hash function
  int hash2(const int);    // second hash function for collision resolution
  int resolve(const int, const int); // Collision resolution function
};

#endif