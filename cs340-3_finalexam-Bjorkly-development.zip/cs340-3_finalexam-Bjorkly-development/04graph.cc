#include "04graph.h"
#include <iostream>
#include "graph.h"
#include <fstream>
#include <string>
#include <sstream>

// Constructor
// Reads the file passed as argument and stores the contents in containers defined in the graph.h
// 1. The vertices in "labels"
// 2. The adjacency matrix representation in "adj_matrix"
// 3. The list of vertex sequence in "sequence"
//
// In the input file -
//  Row 1: number of vertices, say V
//  Row 2: list of V vertex names
//  Row 3: number of edges, say E
//  Row 4: from row 4, next E rows store E "DIRECTED" edges
//  last row: a sequence of vertices to be validated
Graph::Graph(const char *filename)
{
    std::fstream myfile;
    // Opens the inputfile
    myfile.open(filename);

    // Reads the inputfile
    std::string n;

    myfile >> n;
    // Converts any element for size into anything that is needed
    size = std::stoi(n);

    // Resizes each vector to fit any size
    labels.resize(size);
    adj_matrix.resize(size);
    
    // reads the labels and puts them into a vector
    for(int i=0; i<size; i++)
    {
        myfile >> n;
        labels[i] = (n[0]);
    }

    // reads the elements into a list? I forgot
    for(int j=0; j<size; j++)
    {
        myfile >> n;
        // reads the elements into a list
        for(int k=0; k<size; k++)
        {
            myfile >> n;
            if (n=="1")
            {
                adj_matrix[j].push_back(k);
            }
        }
    }   myfile.close();
}

// Destructor
Graph::~Graph()
{}

// This public function prints the
//  1. Adjacency matrix representation of given graph.
//      You MUST a width of 3 for all the labels and the values.
//  2. Each Sequence followed by Valid/Invalid string.
void Graph::Print() const
{
  std::cout<<std::endl;
  std::cout<< "Number of vertices in the graph: "<<size<<std::endl<<std::endl;

  std::cout<< "-------- graph -------"<<std::endl;

    // Suppose to go through the vector and print them with a width of 3
    for( auto i = adj_matrix[i].begin(); i != adj_matrix[i].end(); ++i)
    {
      std::cout<<setw(3)<<labels[i]<<value[1]<<endl;
    }
  std::cout<<"------- end of graph ------"<<std::endl<<std::endl;

  // Each Sequence followed by Valid/Invalid string. So bloddy tired....
  isValidSequence = true;
  {
    std::cout<< sequence << "Valid";
  }
  std::cout<< sequence << "Invalid";
  

}

// This private function is called inside Print method to test if a given sequence is valid path
// Argument sequence - indicates the set of vertices to be tested.
bool Graph::isValidSequence() const
{
  int valid = true;

  return valid;
}
