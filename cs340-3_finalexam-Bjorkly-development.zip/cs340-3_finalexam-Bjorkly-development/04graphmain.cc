#include "04graph.h"
#include <iostream>

using std::cerr;

int main(int argc, char **argv)
{
  if (argc < 2)
  {
    cerr << "args: input-file-name\n";
    return 1;
  }

  Graph g(argv[1]);

  g.Print();
  return 0;
}