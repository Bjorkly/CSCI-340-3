#include "02btree.h"
#include <algorithm>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

using namespace std;

#define SEED 122021 // seed for RNG
#define N 10        // num of rand ints

unsigned sz; // size of vector/binTree

// class to generate rand ints
class RND
{
private:
  int seed;

public:
  RND(const int &s = SEED) : seed(s) { srand(seed); }
  int operator()() { return rand() % N + 1; }
};

// function to print elems on stdout
template <typename T>
void print(const T &x)
{
  cout << x << ' ';
}

int main()
{
  vector<int> v(N); // holds rand ints
  vector<int> w = {1, 2, 4, 5, 3, 7, 6, 8};
  BinaryTree<int> t; // bin search tree ( BST )
  BinaryTree<int> s; // bin search tree ( BST )

  // generate rand ints
  generate(v.begin(), v.end(), RND());

  // insert ints in vector into BST
  for (unsigned i = 0; i < v.size(); i++)
    t.Insert(v[i]);

  cout << "Preorder: ";
  t.Preorder(print<int>);
  cout << endl;

  cout << "Inorder: ";
  t.Inorder(print<int>);
  cout << endl;

  cout << "Postorder: ";
  t.Postorder(print<int>);
  cout << endl;

  // insert ints in vector into BST
  for (unsigned i = 0; i < w.size(); i++)
    s.Insert(v[i]);

  cout << "Preorder: ";
  s.Preorder(print<int>);
  cout << endl;

  cout << "Inorder: ";
  s.Inorder(print<int>);
  cout << endl;

  cout << "Postorder: ";
  s.Postorder(print<int>);
  cout << endl;

  return 0;
}
