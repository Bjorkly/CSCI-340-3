#ifndef H_BINARYTREE
#define H_BINARYTREE
#include "node.h"
#include <stdlib.h>

typedef enum
{
  left_side,
  right_side
} SIDE;

SIDE rnd() { return rand() % 2 ? right_side : left_side; } // End of rnd()

template <typename T>
class BinaryTree
{
public:
  BinaryTree();                        // default constructor
  unsigned getSize() const;            // returns size of tree
  unsigned getHeight() const;          // returns height of tree
  virtual void Insert(const T &);      // inserts node in tree
  void Preorder(void (*)(const T &));  // inorder traversal of tree
  void Inorder(void (*)(const T &));   // inorder traversal of tree
  void Postorder(void (*)(const T &)); // inorder traversal of tree

protected:
  Node<T> *root; // root of tree

private:
  unsigned _getSize(Node<T> *) const;              // private version of getSize()
  unsigned _getHeight(Node<T> *) const;            // private version of getHeight()
  void _Insert(Node<T> *&, const T &);             // private version of Insert()
  void _Preorder(Node<T> *, void (*)(const T &));  // private version of Inorder()
  void _Inorder(Node<T> *, void (*)(const T &));   // private version of Inorder()
  void _Postorder(Node<T> *, void (*)(const T &)); // private version of Inorder()
};

template <typename T>
BinaryTree<T>::BinaryTree()
{
  root = nullptr;
}

template <typename T>
unsigned BinaryTree<T>::getSize() const
{
  return _getSize(root);
}

template <typename T>
unsigned BinaryTree<T>::getHeight() const
{
  return _getHeight(root);
}

template <typename T>
void BinaryTree<T>::Insert(const T &value)
{
  return _Insert(root, value);
}

template <typename T>
void BinaryTree<T>::Inorder(void (*printFunction)(const T &value))
{
  return _Inorder(root, printFunction);
}

template <typename T>
unsigned BinaryTree<T>::_getSize(Node<T> *node) const
{
  if (node == nullptr)
    return 0;
  else
    return 1 + _getSize(node->left) + _getSize(node->right);
}

template <typename T>
unsigned BinaryTree<T>::_getHeight(Node<T> *node) const
{
  if (node == nullptr)
    return 0; // empty tree
  else
  {
    int left = _getHeight(node->left);   // left side
    int right = _getHeight(node->right); // right side

    if (left > right)  // which is greater
      return 1 + left; // return left
    else
      return 1 + right; // return right
  }                     // End of ELSE
} // End of _getHeight()

template <typename T>
void BinaryTree<T>::_Insert(Node<T> *&node, const T &value)
{
  if (node == nullptr)
    node = new Node<T>(value, nullptr, nullptr);
  else
  {
    if (rnd() == right_side)
      _Insert(node->right, value);
    else
      _Insert(node->left, value);
  } // End of IF/ELSE
} // End of _Insert

template <typename T>
void BinaryTree<T>::_Inorder(Node<T> *node, void (*printFunc)(const T &value))
{
  if (node == nullptr)
    return;

  _Inorder(node->left, printFunc);
  printFunc(node->data);
  _Inorder(node->right, printFunc);
} // End of _Inorder()

#endif // End of H_BINARYTREE
