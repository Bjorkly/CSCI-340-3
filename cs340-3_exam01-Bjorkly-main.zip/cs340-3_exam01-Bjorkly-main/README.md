# CS340.1 Exam01

You will complete this exam in 50 minutes, both parts will be done in class. You may not use any website other than *Microsoft Forms*, *GitHub*, and *www.cplusplus.com*.

## Part One (75 Points) Microsoft Forms

You can find the Microsoft Forms portion of the exam at URL: https://forms.office.com/r/a8NE1Qzh1N

## Part Two (25 Points) C++ Programming
Please complete the following two programming questions. Follow the class's workflow, having accepted the GitHub Classroom invitation, now browse to newly created GitHub repository, create a **_development_** branch, clone repository to the local machine, or turing/hopper/whick, complete exam, `git commit` and `git push` your results. Issue a single pull request that the exam is now ready for grading.

`git commit` and `git push` your local repository to GitHub for grading by the turn-in deadline **(end of 50 minutes)**. Failure to do so on time will result in a **zero** for this portion of the exam.

- **Do not edit the Makefile** in the repository. It provides all functionality needed for the exam. The files inside the brack for each question are the only files you are to modify.

1. (13 points) [recursion.cc] Write a program using recursion to calculate first **m** numbers in a series where each number is calculated using the function **f(n)**. The function **f(n)** is expressed as: ![recursiveexpression](recursionformula.jpg) 

2. (12 points) [binarysearchtree.h]
Using the included code; modify the binary search tree class (`BinarySearchTree`), adding the following four functions to where appropriate. 

    - `T getMaxValue()` returns the maximum value in the tree, this function calls the private *_gitMaxValue()* function
    - `T _getMaxValue()` returns the maximum value in tree
    - `T getMinValue()` returns the minimum value in the tree, this function calls the private *_gitMinValue()* function
    - `T _getMinValue()` returns the minimum value in tree

