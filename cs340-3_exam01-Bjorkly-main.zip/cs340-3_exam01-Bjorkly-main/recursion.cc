/*
 *	Instructor: Total - 9/13
 *		- -1 : Wrong recursive expression. There is no case that returns 0 when input is 0.
 *		- -3 : Didn't calculate the series. Ex: If input is 5, print first 5 numbers in the series.
 *
 *      - Always use constants instead of hard coded values for ex: width=4, values_per_line=5
 *
*/

/*
 *  In this question, you will use recursion to calculate the value of a fucntion.
 *
 *  Write a program that performs the following -
 *  1. Implements the function given in the README file
 *  2. Generate the series of first n numbers i.e., f(0), f(1), f(2), ..., f(n-1)
 *  3. Format the output series such that each line has 5 numbers and each number uses a width of 4
 *
 */

#include <iomanip>
#include <iostream>
using std::cin;
using std::cout;
using std::endl;
using std::setw;

const int NO_ITEMS = 5;
const int ITEM_COUNT_WIDTH = 4;

// implement the recursive function
int recursiveExpression (int n)
{
    if(n==0)
    {
        return 0;
    }
    else if(n<1)
    {
        return 1;
    }
    else if( 1<=n && n<=2)
    {
        return n+1;
    }
    else if(n>2)
    {
        return recursiveExpression(n-1) + recursiveExpression(n-3) - recursiveExpression(n-2)/2;
    }
    return 0;
}
int main()
{
    int n;

    // Read how many numbers from the series are to be calculated
    cout << "Results for f_n will be calculated from 0 to n" << endl;
    cout << "Please enter n: ";
    cin >> n;

    cout << "0 to " << n << " numbers of the series represented by the given expression are :" << endl;

    // call the recursive function to calculate each number in the series and
    // print the series using specified formatting
    cout << setw(NO_ITEMS) << recursiveExpression(n) << setw(ITEM_COUNT_WIDTH) << endl;
    cout << endl;
    return 0;
}