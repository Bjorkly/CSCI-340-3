/*
 *	Instructor: Total - 3/12
 *		- -3 : Compile errors!
 *		- -6 : No code implemented for finding min/max values
 *
*/

#include "binarytree.h"
#include "node.h"
#ifndef BINARYSEARCHTREE_H_
#define BINARYSEARCHTREE_H_
#include <fstream>
#include <iostream>
#include <string>

using namespace std;

template <typename T>
class BinarySearchTree : public BinaryTree<T>
{
public:
  void Insert(const T &x);       // inserts node with value x
  bool Search(const T &x) const; // searches leaf with value x
  unsigned T getMaxValue(const T &x) const;// finds max value
  bool Remove(const T &x);       // removes leaf with value x

private:
  void _Insert(Node<T> *&, const T &);      // private version of insert
  bool _Search(Node<T> *, const T &) const; // private version of search
  unsigned T getMaxValue(const T &x) const; // find max value
  void _Remove(Node<T> *&, const T &);      // private version of remove
  bool _Leaf(Node<T> *) const;              // checks if node is leaf
};

template <typename T>
void BinarySearchTree<T>::Insert(const T &value)
{
  return _Insert(this->root, value);
}

template <typename T>
bool BinarySearchTree<T>::Search(const T &x) const
{
  return _Search(this->root, x);
}

template <typename T> BinarySearchTree<T>:: getMaxValue(const T &x)
{
  return _getMaxValue(this->root, x);
}
template <typename T>
bool BinarySearchTree<T>::Remove(const T &x)
{
  if (Search(x))
  {
    _Remove(this->root, x);
    return true;
  }
  else
    return false;
}

template <typename T>
void BinarySearchTree<T>::_Insert(Node<T> *&node, const T &insertedValue)
{
  if (node == nullptr)
    node = new Node<T>(insertedValue, nullptr, nullptr);
  else if (insertedValue < node->data)
    _Insert(node->left, insertedValue);
  else if (insertedValue > node->data)
    _Insert(node->right, insertedValue);
  else
    return;
} // End of _Insert

template <typename T>
bool BinarySearchTree<T>::_Search(Node<T> *r, const T &value) const
{
  if (r == nullptr)
    return false;
  else if (r->data == value)
    if (_Leaf(r))
      return true;
    else
      return false;
  else if (value < r->data)
    return _Search(r->left, value);
  else
    return _Search(r->right, value);
} // End of _Search


template <class T>
unsigned BinarySearchTree<T>::_getMaxValue(Node<T> *r, const T &value)
{
  BinaryNode *findMax(BinaryNode *t) const
  {
    if (t !=)
  }
}

template <class T>
void BinarySearchTree<T>::_Remove(Node<T> *&r, const T &value)
{
  if (r == nullptr)
    return;
  else if (r->data == value)
  {
    if (_Leaf(r))
    {
      delete r;
      r = nullptr;
    } // End of IF
  }
  else if (value < r->data)
    _Remove(r->left, value);
  else
    _Remove(r->right, value);
} // End of REMORE

template <class T>
bool BinarySearchTree<T>::_Leaf(Node<T> *node) const
{
  if ((node->left == nullptr) && (node->right == nullptr))
    return true;
  else
    return false;
} // End of LEAF

#endif // End of BINARYSEARCHTREE_H_