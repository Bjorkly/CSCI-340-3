#include "binarysearchtree.h"
#include <algorithm>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

#define SEED 1 // seed for RNG
#define N 100  // num of rand ints
#define M 50   // num of rand ints

#define NO_ITEMS 10 // max num of elems printed in line
#define ITEM_W 5    // size of each elem in print

// class to generate rand ints
class RND
{
private:
  int seed;

public:
  RND(const int &s = SEED) : seed(s) { srand(seed); }
  int operator()() { return rand() % N + 1; }
};

#define STRING_LENGTH 4

class RW
{
private:
  int seed;

public:
  RW(const int &s = SEED) : seed(s) { srand(seed); }
  string operator()()
  {
    string w;
    int len = rand() % STRING_LENGTH + 1;
    while (len)
    {
      w += 'a' + rand() % 26;
      len--;
    }
    return w;
  }
};

unsigned sz; // size of vector/binTree

// function to print elems on stdout
template <typename T>
void print(const T &x)
{
  static unsigned cnt = 0;

  cout << setw(ITEM_W) << x << ' ';
  cnt++;
  if (cnt % NO_ITEMS == 0 || cnt == sz)
    cout << endl;
  if (cnt == sz)
    cnt = 0;
}

int main()
{
  vector<int> v(N);        // holds rand ints
  BinarySearchTree<int> t; // bin search tree ( BST )

  // generate rand ints
  generate(v.begin(), v.end(), RND());

  // print contents of vector
  cout << "Original Vector " << endl;
  sz = v.size();
  for_each(v.begin(), v.end(), print<int>);
  cout << endl;

  // insert ints in vector into BST
  for (unsigned i = 0; i < v.size(); i++)
    t.Insert(v[i]);

  sz = t.getSize();
  cout << "Size: " << t.getSize();
  cout << " Minumum Value: " << t.getMinValue() << " Maximum Value: ";
  cout << t.getMaxValue() << endl;

  vector<string> u(M);        // holds rand strings
  BinarySearchTree<string> s; // bin search tree ( BST )

  // generate rand ints
  generate(u.begin(), u.end(), RW());

  // print contents of vector
  cout << "Original Vector " << endl;
  sz = u.size();
  for_each(u.begin(), u.end(), print<string>);
  cout << endl;

  // insert strings in vector into BST
  for (unsigned i = 0; i < u.size(); i++)
    s.Insert(u[i]);

  sz = s.getSize();
  cout << "Size: " << s.getSize();
  cout << " Minumum Value: " << s.getMinValue() << " Maximum Value: ";
  cout << s.getMaxValue() << endl;

  return 0;
}
