/*TA Comments:
7/10
-program not compiled
-error in code
*/


/*      Berkley Phelps
        Z1906725
        CS340.3

        I certify that this is my own work and where appropriate an extension
        of the starter code provided for the assignment.
*/

#include <iostream>
#include <string>
#include <map>
#include <algorithm>
#include <ctype.h>
#include <locale>
using namespace std;

const int NO_ITEMS = 4;
const int ITEM_WORD_WIDTH = 14;

void get_words(map<string, int>& words)
{
  string word;
  string cleanedUpWord;
  int i;
  while (cin >> word )
  {
    
    //makes the letters lower case
    locale loc;
    for( string::size_type i=0; i<word.length(); i++)
    {
      word[i]= tolower(word[i],loc);
    }   
  //clean_entry(word, cleanUpWord);
   
    //stores letters
    if(word.length()!=0)
    {
      words[word]++;
    }
  }
}

//prints the final list of words and their frequencies
void print_words(const map<string, int>& words)
{ //reads 
  for(auto it=words.begin(); it!= words.end(); it++)
  {
    cout<<it->first<< " "<< it ->second<<endl;
  }

    //The two comments belowe are supposed to print out the words in proper format

    //cout<<words.size()<<NO_ITEMS
    //cout<<std::left<<NO_Items<<words.first()<< ":"<<ITEM_WORD_WIDTH<<words.second<<ITEM_COUNT_WIDTH;

}


//cleans a word from its punctaution marks
void clean_entry(const string& OG_Word, string& Mod_Word)
{
  int firstletter = 0;
  int lastletter = 0;

  for (int i=0; i<OG_Word.length(); i++)
  {
    //checks if the characters are alphanumeric
    char str[]="y3a...";
    int j=0;
    while(isalnum(str[j])) j++; 
  }
  //Copy the the first alphanumeric character until the last one to a new string
  string s;
  s.substr(OG_Word, Mod_Word);




}


int main()
{
  //bdp stores formatted words
  map<string, int> bdp;
  get_words(bdp);

  //cleans up the words
  //clean_entry(bdp);

  //prints the words
  print_words(bdp);


}
